#! /usr/bin/perl
 use Time::HiRes qw( usleep ualarm gettimeofday tv_interval nanosleep
                      clock_gettime clock_getres clock_nanosleep clock
                      stat lstat );

my $start = Time::HiRes::gettimeofday();
while (1)
{
	my $end = Time::HiRes::gettimeofday();
	my $temp = $end - $start;
	print "the current time is : $temp\n";
	if ($temp >= 120)
	{
		print "go out\n";
		last;
	}
	else
	{
		print "continue in loop\n";
	}
}
